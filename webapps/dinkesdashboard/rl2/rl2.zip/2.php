<?php
 include '../conf/conf.php';
   /* header("Content-type: application/x-msdownload");
    header("Content-Disposition: attachment; filename=LaporanRekapKunjuangnJenisBayar.xls");
    header("Pragma: no-cache");
    header("Expires: 0");
    print "$header\n$data";*/
?>

    <div class="panel-heading">
		<h4>RL 2 - Ketenagaan </h4></div>
			<div class="panel-body">
    <?php
	switch($_GET[act]){
	default:
    echo"<form action='?module=2&act=simpan' method='post'>
	<table>
	<tr>
	<td>Jabatan Fungsional</td><td>:</td><td>
	<select name='jabatanfungsional'>
	
	<option >Dokter Umum</option>
	<option >Dokter Gigi</option>
	<option >Dokter Gigi Spesialis</option>
	<option >Dokter Spes Obgin</option>
	<option >Dokter Spes Penyakit Dalam</option>
	<option >Dokter Spes Kes. Anak</option>
	<option >Dokter Spes Radiologi</option>
	<option >Dokter Spes Paru</option>
	<option >Dokter Spes Anasthesi</option>
	

	</select> </td>
	</tr>
	<tr>
	<td>Jenis Tenaga Kerja</td><td>:</td><td>
	<select name='jenistenagakerja'>
	<option value='tenaga_medis'>Tenaga Medis</option>
	<option value='tenaga_non_medis'>Tenaga Non Medis</option>
	
	</select></td>
	</tr>
	<tr>
	<td>Jumlah</td><td>:</td>
	<td><input type='text' name='jumlahtenagakerja'/>
	</td>
	</tr>
	
	<tr>
	<td>
<input type='submit' value='Simpan' class='btn btn-primary' ></td>
	</tr>
	</table>
	</form>
	<br>
<table class='table table-bordered table-hover table-striped' data-toggle='table'>
		<thead>
		<tr>
		<td>No</td>
		<td>Jabatan Fungsional</td>
		<td>Jenis Tenaga</td>
		<td>Jumlah</td>
		
		</tr>
		</thead>";?>
<?php 
$ppkkode="SELECT * FROM setting";
		$ppk_kode=bukaquery($ppkkode);
 while($ppk = mysql_fetch_array($ppk_kode)) { 
			$k_ppk=$ppk['kode_ppk'];
			$n_ppk=$ppk['nama_ppk'];
		 }
$_sql = "SELECT * FROM ketenagaan";  
$hasil=bukaquery($_sql); $no=1;
                 while($baris = mysql_fetch_array($hasil)) { 
                 	$myvars="";
				$post[] = array(
	
					'koders'=>$k_ppk,
  					'jabatanfungsional'=>$baris['jabatanfungsional'],
  					'jenistenagakerja'=>$baris['jenistenagakerja'],
  					'jumlahtenagakerja'=>$baris['jumlahtenagakerja']
					);
$myvars=json_encode($post);
              switch($baris['jenistenagakerja'])
              {
              	case "tenaga_medis": $tenaga="Tenaga Medis";
              	break;
              	case "tenaga_non_medis": $tenaga="Tenaga Non Medis";
              	break;
              }

echo"

		<tr>
		<td>".$no++."</td>
		<td>".$baris['jabatanfungsional']."</td>
		<td>".$tenaga."</td>
		<td>".$baris['jumlahtenagakerja']."</td>
		</tr>";
	}
	echo"

</table>
	<br><br>";
	?>
	<form action='?module=2&act=kirim' method='post'>
		<input type='hidden' value='<?php echo $myvars; ?>' name='kirim'>
		<button id="submit" name="submit" class="btn btn-success" type="submit">Kirim Data</button>
		</form>
		<br>
		<br>
	<?php

	break;
	
	case "simpan":
	$tabelname="ketenagaan";
		$jabatanfungsional      = $_POST['jabatanfungsional'];
		$jenistenagakerja      = $_POST['jenistenagakerja'];  
		$jumlahtenagakerja      = $_POST['jumlahtenagakerja']; 

		$attrib="'','$jabatanfungsional','$jenistenagakerja','$jumlahtenagakerja'" ;
		$pesan="$jabatanfungsional";
    
    Tambah($tabelname,$attrib,$pesan);
    echo "<script>alert('Data Berhasil Disimpan'); window.location = '?module=2'</script>";

		
?>

	<?php break ; 
	case  "kirim":
$myvars=$_POST['kirim'];
	
$url= "http://eis.dinkes.jakarta.go.id/api/curl/ws-rl2.php";
		require_once('../conf/curl-send.php');	
		echo "<script>alert('Data Insya Allah Sudah Di Kirim'); window.location = 'javascript:history.go(-1)'</script>";
 break; 
	

}
?>	
   